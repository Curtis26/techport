
public class Launcher {
	
	public static void main(String[] args) {
		Application myApp = new Application();

	try {
		myApp.start();	
	}catch(Exception e){
		System.out.println("Hello");
	}
}
}